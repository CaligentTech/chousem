<?php

/** @var array<string, mixed> $s */
if (!isset($s) || !is_array($s)) {
    if (file_exists(__DIR__ . '/db.php') && file_exists(__DIR__ . '/functions.php')) {
        require_once __DIR__ . '/db.php';
        require_once __DIR__ . '/functions.php';
        $s = isset($pdo) ? get_all_settings($pdo) : [];
    } else {
        $s = [];
    }
}
if (!function_exists('e')) {
    function e($str)
    {
        return htmlspecialchars((string)($str ?? ''), ENT_QUOTES, 'UTF-8');
    }
}
?>
<!-- SIMPLE FOOTER (shared partial) -->
<footer class="bg-black px-5 py-6 text-center text-[10px] uppercase tracking-[.14em] text-[var(--mora-candle)]/70">
    <?= e($s['footer_copyright'] ?? '© C HOUSE Dubai') ?>
</footer>